public class Mate extends Getraenk {
    public Mate(String name) {
        super(name, 500, 100);
    }
}