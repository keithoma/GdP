public class Wasser extends Getraenk {
    public Wasser(String name, int menge) {
        super(name, menge, 200);
    }
}