public class Kaese extends Speise {
    public Kaese (String name, int menge) {
        super(name, menge, 20);
    }

}